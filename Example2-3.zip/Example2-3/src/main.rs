use std::iter::Sum;
use std::collections::HashMap;
use std::fmt;
use std::hash::Hash;

struct EdgeEntry<ID,E>{
    tail: ID,
    head: ID,
    edge: E,
}


struct NodeEntry<ID, N, E>{
    generic_node1: ID,
    edges: Vec<EdgeEntry<ID,E>>,
    node_type: N,
}

struct Graph<ID, N, E>
where
    ID: Eq + Hash + Copy + Clone + fmt::Display,
    N: fmt::Display,
    E: fmt::Display,
{
    nodes: HashMap<ID, NodeEntry<ID,N, E>>,
}
//will implement ID, N, E with the graph as its parameters and do the same from the bottom as in the top
impl <ID, N, E,> Graph<ID, N, E>
where
    ID: Eq + Hash + Copy + Clone + std::fmt::Display,
    N: fmt::Display,
    E: fmt::Display,
{
    pub fn new() -> Graph<ID, N, E> {
        Graph{nodes: HashMap::new()}
    }

    fn add_node(&mut self, id: ID, node_type: N){
        if !self.nodes.contains_key(&id) {
            self.nodes.insert(
                id,
                NodeEntry{
                    generic_node1: id,
                    edges: Vec::new(),
                    node_type,
                },
            );
        }
    }

    fn add_edge(&mut self, tail: ID, head: ID, edge: E){
        if self.nodes.contains_key(&tail) && self.nodes.contains_key(&head){
            let edge = EdgeEntry{tail: tail, head: head, edge};
            if let Some(node) = self.nodes.get_mut(&tail){
                node.edges.push(edge);
            }
        }
    }

    fn num_nodes(&self) -> usize{
        self.nodes.len()
    }

    fn num_edges(&self) -> usize {
        self.nodes.values().map(|node| node.edges.len()).sum::<usize>()
    }

}

//the ID: the graph must have equality, use hash map, make a deep copy of itseld and be able to clone and print itself with the fmt::Display
impl<ID, N, E> fmt::Display for Graph<ID, N, E>
where
    ID: Eq + Hash + Copy + Clone + fmt::Display,
    N: fmt::Display,
    E: fmt::Display,
{
    //this will format the result in the playground function mapping the ID and making a string collecting all the strings and putting them together
    // we do the same for the edges as well
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let node_keys: Vec<&ID> = self.nodes.keys().collect();
        let node_str = node_keys
            .iter()
            .map(|id| id.to_string())
            .collect::<Vec<String>>()
            .join(",");

        let mut edge_vec = Vec::new();
        for(_, node_entry) in &self.nodes{
            for edge in &node_entry.edges {
                edge_vec.push(format!("{} {}", edge.tail, edge.head));
            }
        }
        let edge_str = edge_vec.join(",");
        //this gives random outputs everytinme and i dont understand why, it will abc, ab, ac, bc or another pattern
        write!(f, "G=({{ {} }},{{ {} }})", node_str, edge_str)

    }
}

fn playground(){
    //created a and integer graph and converted the id to a string and so it will print abc ab bc ac as a result
    let mut int_graph = Graph::<char, String, f64>::new();
    int_graph.add_node('a', "Node A".to_string());
    int_graph.add_node('b', "Node B".to_string());
    int_graph.add_node('c', "Node C".to_string());
    int_graph.add_edge('a', 'b', 1.0);
    int_graph.add_edge('b', 'c', 2.5);
    int_graph.add_edge('a', 'c', 3.0);

    println!("Integer Graph");
    println!("Number of Nodes: {}", int_graph.num_nodes());
    println!("Number of Edges: {}", int_graph.num_edges());
    println!("{}", int_graph);

   // will not work, im pretty sure it is from my display format in getting the bounds correct for this
    //let mut string_graph = Graph::<String, i32, ()>::new();
    //string_graph.add_node("Start".to_string(), 0);
   // string_graph.add_node("middle".to_string(), 1);
    //string_graph.add_node("end".to_string(), 2);

   // println!("String Graph");
   // println!("Number of Nodes: {}", string_graph.num_nodes());
   // println!("Number of Edges: {}", string_graph.num_edges());
}


//calls my playground function from above
fn main() {
    playground();
}




